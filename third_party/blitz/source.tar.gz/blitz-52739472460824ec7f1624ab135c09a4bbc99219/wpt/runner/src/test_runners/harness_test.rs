//! Runner for testharness.js tests: executes the test file's JavaScript (including
//! the real testharness.js framework) using `blitz-vibey-script`, and collects the
//! harness results via a custom `testharnessreport.js`.

use std::path::PathBuf;
use std::time::Duration;

use blitz_vibey_script::{FetchError, ScriptFetcher};
use log::{debug, warn};
use url::Url;

use super::{SubtestResult, parse_and_resolve_document, pump_timers, run_document_scripts};
use crate::{SubtestCounts, TestStatus, ThreadCtx};

/// How long to wait for the harness to complete (async tests, timers)
const HARNESS_TIMEOUT: Duration = Duration::from_secs(10);

/// Custom `testharnessreport.js` served in place of WPT's stock one (which is
/// designed to be replaced by test runners). It disables the DOM output section
/// and reports results to the runner via the `__blitz_send_message` native
/// function provided by blitz-vibey-script.
///
/// The `timeout_multiplier` scales down testharness's internal timeout (10s by
/// default) so that tests which will never complete (e.g. ones waiting for
/// events that Blitz never fires, or for testdriver.js automation) report a
/// TIMEOUT harness status quickly instead of hitting the runner's
/// [`HARNESS_TIMEOUT`] backstop. It also proportionally shortens
/// `step_timeout()` delays, speeding up legitimately-passing async tests.
///
/// The internal timeout is real (wall-clock) time and races against the
/// test's own script execution, so it must comfortably exceed the runtime of
/// the heaviest completing tests (the interpolation suites run for ~1s of
/// script time each, longer on loaded CI machines) or their results flap
/// between TIMEOUT and their true status from run to run.
const TESTHARNESSREPORT_JS: &str = r#"
setup({ output: false, debug: false, timeout_multiplier: 0.5 });
add_completion_callback(function (tests, harness_status) {
    __blitz_send_message(JSON.stringify({
        type: "wpt_results",
        harness_status: {
            status: harness_status.status,
            message: harness_status.message,
        },
        tests: tests.map(function (test) {
            return { name: test.name, status: test.status, message: test.message };
        }),
    }));
});
"#;

/// Custom `testdriver-vendor.js` served in place of WPT's stock one (an empty
/// file which automation environments are expected to replace).
///
/// Blitz has no testdriver automation backend. Without a vendor file,
/// testdriver.js commands like `test_driver.click()` fall back to waiting for
/// a *real user* to perform the action, so such tests hang until the harness
/// timeout. Setting `in_automation` makes every command reject immediately
/// ("...not implemented by testdriver-vendor.js" errors from testdriver.js's
/// default `test_driver_internal` implementations); wrapping those commands lets
/// the runner skip the unsupported test as soon as one is invoked.
const TESTDRIVER_VENDOR_JS: &str = r#"
window.test_driver_internal.in_automation = true;
(function wrapUnsupportedCommands(value, prefix) {
    Object.keys(value).forEach(function (key) {
        const child = value[key];
        const command = prefix ? prefix + "." + key : key;
        if (typeof child === "function") {
            value[key] = function () {
                __blitz_send_message(JSON.stringify({
                    type: "unsupported_feature",
                    feature: "testdriver",
                    command: command,
                }));
                return child.apply(this, arguments);
            };
        } else if (child && typeof child === "object") {
            wrapUnsupportedCommands(child, command);
        }
    });
})(window.test_driver_internal, "");
"#;

/// A [`ScriptFetcher`] which resolves script URLs against the local WPT checkout,
/// and intercepts `/resources/testharnessreport.js` and
/// `/resources/testdriver-vendor.js` to serve the custom versions above.
pub struct WptScriptFetcher {
    wpt_dir: PathBuf,
}

impl WptScriptFetcher {
    pub fn new(wpt_dir: PathBuf) -> Self {
        Self { wpt_dir }
    }
}

impl ScriptFetcher for WptScriptFetcher {
    fn fetch(&self, url: &Url) -> Result<String, FetchError> {
        let mut path = url.path();
        if path.ends_with("/resources/testharnessreport.js") {
            return Ok(TESTHARNESSREPORT_JS.to_string());
        }
        if path.ends_with("/resources/testdriver-vendor.js") {
            return Ok(TESTDRIVER_VENDOR_JS.to_string());
        }
        // wptserve rewrites this URL (see `rewrites` in tools/serve/serve.py)
        if path == "/resources/WebIDLParser.js" {
            path = "/resources/webidl2/lib/webidl2.js";
        }
        let relative_path = path.strip_prefix('/').unwrap_or(path);
        std::fs::read_to_string(self.wpt_dir.join(relative_path)).map_err(FetchError::Io)
    }
}

enum HarnessPumpOutcome {
    Results(i64, Vec<SubtestResult>),
    UnsupportedFeature(String, String),
}

pub fn process_harness_test(
    ctx: &mut ThreadCtx,
    html: &str,
    relative_path: &str,
) -> (TestStatus, SubtestCounts, Vec<SubtestResult>) {
    let document = parse_and_resolve_document(ctx, html, relative_path);
    let mut document = run_document_scripts(ctx, document);

    // Pump timers until the harness reports results (or the timeout expires).
    // Synchronous tests complete during `execute_scripts` (testharness completes
    // on the `load` event); async tests may schedule timers.
    //
    // Uncaught JS errors are dispatched to testharness's window `error` handler
    // (as in a browser), which records a harness ERROR alongside the subtests
    // completed so far and completes the harness. So they don't end the run on
    // their own; they only decide the outcome if the harness never reports.
    let mut js_errors = Vec::new();
    let outcome = pump_timers(&mut document, HARNESS_TIMEOUT, |document| {
        let messages = document.take_messages();
        if let Some((feature, command)) = messages
            .iter()
            .find_map(|msg| parse_unsupported_feature(msg))
        {
            return Some(HarnessPumpOutcome::UnsupportedFeature(feature, command));
        }
        if let Some((status, results)) = messages.iter().find_map(|msg| parse_results(msg)) {
            return Some(HarnessPumpOutcome::Results(status, results));
        }
        js_errors.extend(document.take_js_errors());
        None
    });
    js_errors.extend(document.take_js_errors());
    for error in &js_errors {
        warn!("{relative_path}: {error}");
    }

    match outcome {
        Some(HarnessPumpOutcome::Results(harness_status, subtest_results)) => {
            harness_outcome(harness_status, subtest_results)
        }
        Some(HarnessPumpOutcome::UnsupportedFeature(feature, command)) => {
            debug!("Skipping {relative_path}: unsupported {feature} command {command}");
            (TestStatus::Skip, SubtestCounts::ZERO_OF_ZERO, Vec::new())
        }
        // The harness never reported, and an uncaught error is the likely cause
        // (e.g. it threw before testharness.js was even loaded)
        None if !js_errors.is_empty() => {
            let subtest_results = vec![SubtestResult {
                name: "Uncaught JS error".to_string(),
                status: TestStatus::Fail,
                errors: js_errors,
            }];
            (
                TestStatus::Fail,
                SubtestCounts::ZERO_OF_ONE,
                subtest_results,
            )
        }
        // Timeout, or no pending timers: the harness will never complete
        None => {
            warn!("{relative_path}: testharness.js did not report results");
            (TestStatus::Timeout, SubtestCounts::ZERO_OF_ONE, Vec::new())
        }
    }
}

/// Harness statuses: 0 = OK, 1 = ERROR, 2 = TIMEOUT, 3 = PRECONDITION_FAILED
const HARNESS_STATUS_OK: i64 = 0;
const HARNESS_STATUS_TIMEOUT: i64 = 2;
const HARNESS_STATUS_PRECONDITION_FAILED: i64 = 3;

/// Compute the overall test outcome from a testharness.js harness status code
/// and its subtest results. A PRECONDITION_FAILED harness status or subtest
/// status is skip-like (matching WPT's expectations model) rather than a
/// failure; skipped subtests are excluded from the counts entirely.
pub(super) fn harness_outcome(
    harness_status: i64,
    subtest_results: Vec<SubtestResult>,
) -> (TestStatus, SubtestCounts, Vec<SubtestResult>) {
    if subtest_results.is_empty() {
        return match harness_status {
            HARNESS_STATUS_PRECONDITION_FAILED => {
                (TestStatus::Skip, SubtestCounts::ZERO_OF_ZERO, Vec::new())
            }
            HARNESS_STATUS_TIMEOUT => (TestStatus::Timeout, SubtestCounts::ZERO_OF_ONE, Vec::new()),
            // OK with no subtests, or ERROR: fail the test
            _ => (TestStatus::Fail, SubtestCounts::ZERO_OF_ONE, Vec::new()),
        };
    }

    let pass_count = subtest_results
        .iter()
        .filter(|result| matches!(result.status, TestStatus::Pass))
        .count() as u32;
    let skip_count = subtest_results
        .iter()
        .filter(|result| matches!(result.status, TestStatus::Skip))
        .count() as u32;
    let subtest_counts = SubtestCounts {
        pass: pass_count,
        total: subtest_results.len() as u32 - skip_count,
    };
    let status = match harness_status {
        HARNESS_STATUS_OK | HARNESS_STATUS_PRECONDITION_FAILED => subtest_counts.as_status(),
        // A non-OK harness status fails the test even if subtests passed
        HARNESS_STATUS_TIMEOUT => TestStatus::Timeout,
        _ => TestStatus::Fail,
    };

    (status, subtest_counts, subtest_results)
}

fn parse_unsupported_feature(message: &str) -> Option<(String, String)> {
    let value: serde_json::Value = serde_json::from_str(message).ok()?;
    if value.get("type")?.as_str()? != "unsupported_feature" {
        return None;
    }
    Some((
        value.get("feature")?.as_str()?.to_string(),
        value.get("command")?.as_str()?.to_string(),
    ))
}

/// Parse the JSON results message sent by the custom `testharnessreport.js`.
/// Returns the harness status code and the subtest results.
pub(super) fn parse_results(message: &str) -> Option<(i64, Vec<SubtestResult>)> {
    let value: serde_json::Value = serde_json::from_str(message).ok()?;
    if value.get("type")?.as_str()? != "wpt_results" {
        return None;
    }

    let harness_status = value.get("harness_status")?.get("status")?.as_i64()?;
    let subtest_results = value
        .get("tests")?
        .as_array()?
        .iter()
        .map(|test| {
            let name = test
                .get("name")
                .and_then(|name| name.as_str())
                .unwrap_or("")
                .to_string();
            // Test statuses: 0 = PASS, 1 = FAIL, 2 = TIMEOUT, 3 = NOTRUN, 4 = PRECONDITION_FAILED
            let status_code = test.get("status").and_then(|s| s.as_i64()).unwrap_or(1);
            let status = match status_code {
                0 => TestStatus::Pass,
                2 => TestStatus::Timeout,
                // PRECONDITION_FAILED is skip-like, not a failure
                4 => TestStatus::Skip,
                _ => TestStatus::Fail,
            };
            let errors = test
                .get("message")
                .and_then(|msg| msg.as_str())
                .map(|msg| vec![msg.to_string()])
                .unwrap_or_default();
            SubtestResult {
                name,
                status,
                errors,
            }
        })
        .collect();

    Some((harness_status, subtest_results))
}

#[cfg(test)]
mod tests {
    use blitz_dom::DocumentConfig;
    use blitz_html::HtmlDocument;
    use blitz_vibey_script::ScriptDocument;

    use super::*;

    #[test]
    fn testdriver_command_reports_unsupported_feature() {
        let document = HtmlDocument::from_html("<html></html>", DocumentConfig::default());
        let mut document = ScriptDocument::from_base_document(document.into());
        document.eval(
            "window.test_driver_internal = { in_automation: false, send_keys: function () {} };",
        );
        document.eval(TESTDRIVER_VENDOR_JS);
        document.eval("window.test_driver_internal.send_keys();");

        let messages = document.take_messages();
        assert_eq!(messages.len(), 1);
        assert_eq!(
            parse_unsupported_feature(&messages[0]),
            Some(("testdriver".to_string(), "send_keys".to_string()))
        );
    }

    #[test]
    fn ignores_other_messages_as_unsupported_features() {
        assert_eq!(parse_unsupported_feature(r#"{"type":"wpt_results"}"#), None);
    }
}
