use blitz_traits::net::{Bytes, NetHandler, NetProvider, Request};
use data_url::DataUrl;
use log::{debug, warn};
use std::{
    collections::HashMap,
    panic::{AssertUnwindSafe, catch_unwind},
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        atomic::{AtomicUsize, Ordering},
    },
};

static REQUEST_ID: AtomicUsize = AtomicUsize::new(0);

pub struct WptNetProvider<D: Send + Sync + 'static> {
    base_path: PathBuf,
    queue: Arc<InternalQueue<D>>,
}
impl<D: Send + Sync + 'static> WptNetProvider<D> {
    pub fn new(base_path: &Path) -> Self {
        let base_path = base_path.to_path_buf();
        Self {
            base_path,
            queue: Arc::new(InternalQueue::new()),
        }
    }

    pub fn pending_item_count(&self) -> usize {
        self.queue.pending_item_count()
    }

    pub fn log_pending_items(&self) {
        self.queue.log_pending_items();
    }

    pub fn for_each(&self, cb: impl FnMut(D)) {
        self.queue.for_each(cb);
    }

    /// Clear request state (any in-flight requests will be ignored)
    pub fn reset(&self) {
        self.queue.reset();
    }

    fn fetch_inner(
        &self,
        _doc_id: usize,
        request_id: usize,
        request: Request,
        handler: Box<dyn NetHandler>,
    ) -> Result<(), WptNetProviderError> {
        let callback = InternalCallback {
            queue: self.queue.clone(),
        };

        match request.url.scheme() {
            "data" => {
                let url = request.url.as_str().to_string();
                let data_url = DataUrl::process(request.url.as_str()).inspect_err(|_| {
                    callback.queue.record_failure(request_id);
                })?;
                let decoded = data_url.decode_to_vec().inspect_err(|_| {
                    callback.queue.record_failure(request_id);
                })?;
                handler.bytes(url, Bytes::from(decoded.0));

                callback.queue.record_success(None, request_id);
            }
            _ => {
                // TODO: Should we resolve path differently if it does not begin with '/'
                let relative_path = request
                    .url
                    .path()
                    .strip_prefix('/')
                    .unwrap_or(request.url.path());
                let path = self.base_path.join(relative_path);
                let file_content = std::fs::read(&path).inspect_err(|err| {
                    warn!("Error loading {}: {}", path.display(), err);
                    callback.queue.record_failure(request_id);
                })?;
                catch_unwind(AssertUnwindSafe(|| {
                    handler.bytes(request.url.to_string(), Bytes::from(file_content))
                }))
                .map_err(|err| {
                    let str_msg = err.downcast_ref::<&str>().map(|s| s.to_string());
                    let string_msg = err.downcast_ref::<String>().map(|s| s.to_string());
                    let panic_msg = str_msg.or(string_msg);
                    callback.queue.record_failure(request_id);
                    WptNetProviderError::HandlerPanic(panic_msg)
                })?;

                callback.queue.record_success(None, request_id);
            }
        }
        Ok(())
    }
}
impl<D: Send + Sync + 'static> NetProvider for WptNetProvider<D> {
    fn fetch(&self, doc_id: usize, request: Request, handler: Box<dyn NetHandler>) {
        let url = request.url.to_string();

        // println!("Loading {url}");

        let request_id = self.queue.create_request(request.url.to_string());
        let res = self.fetch_inner(doc_id, request_id, request, handler);
        if let Err(e) = res {
            self.queue.record_failure(request_id);
            // if !matches!(e, WptNetProviderError::Io(_)) {
            warn!("Error loading {url}: {e:?}");
            // }
        }
    }
}

#[derive(Debug)]
#[allow(dead_code)]
enum WptNetProviderError {
    Io(std::io::Error),
    DataUrl(data_url::DataUrlError),
    DataUrlBase64(data_url::forgiving_base64::InvalidBase64),
    HandlerPanic(Option<String>),
}

impl From<std::io::Error> for WptNetProviderError {
    fn from(value: std::io::Error) -> Self {
        Self::Io(value)
    }
}

impl From<data_url::DataUrlError> for WptNetProviderError {
    fn from(value: data_url::DataUrlError) -> Self {
        Self::DataUrl(value)
    }
}

impl From<data_url::forgiving_base64::InvalidBase64> for WptNetProviderError {
    fn from(value: data_url::forgiving_base64::InvalidBase64) -> Self {
        Self::DataUrlBase64(value)
    }
}

#[derive(Debug)]
enum RequestStatus {
    InProgress,
    Success,
    Error,
}

struct RequestState<D> {
    url: String,
    status: RequestStatus,
    data: Option<D>,
}

impl<D> RequestState<D> {
    fn new(_id: usize, url: String) -> Self {
        Self {
            url,
            status: RequestStatus::InProgress,
            data: None,
        }
    }
}

struct InternalQueue<T> {
    requests: Mutex<HashMap<usize, RequestState<T>>>,
}
impl<T> InternalQueue<T> {
    pub fn new() -> Self {
        Self {
            requests: Mutex::new(HashMap::new()),
        }
    }

    pub fn reset(&self) {
        self.requests
            .lock()
            .unwrap_or_else(|err| err.into_inner())
            .clear();
    }

    pub fn create_request(&self, url: String) -> usize {
        let request_id = REQUEST_ID.fetch_add(1, Ordering::SeqCst);
        let state = RequestState::new(request_id, url);
        self.requests
            .lock()
            .unwrap_or_else(|err| err.into_inner())
            .insert(request_id, state);
        request_id
    }

    pub fn record_success(&self, data: Option<T>, request_id: usize) {
        let mut requests = self.requests.lock().unwrap_or_else(|err| err.into_inner());
        if let Some(req) = requests.get_mut(&request_id) {
            // println!("Loaded {}", req.url);
            req.status = RequestStatus::Success;
            req.data = data;
        }
    }

    pub fn record_failure(&self, request_id: usize) {
        let mut requests = self.requests.lock().unwrap_or_else(|err| err.into_inner());
        if let Some(req) = requests.get_mut(&request_id) {
            warn!("Error loading {}", req.url);
            req.status = RequestStatus::Error;
        }
    }

    pub fn pending_item_count(&self) -> usize {
        self.requests
            .lock()
            .unwrap_or_else(|err| err.into_inner())
            .len()
    }

    pub fn log_pending_items(&self) {
        let requests = self.requests.lock().unwrap_or_else(|err| err.into_inner());
        for (id, req) in requests.iter() {
            debug!("Req {}: {} ({:?})", id, req.url, req.status);
        }
    }

    pub fn for_each(&self, mut cb: impl FnMut(T)) {
        // Note: we use a temporary Vec here so that the mutex is unlocked prior to any of the callbacks being called.
        // This prevents the mutex from being poisoned if any of the callbacks panic, allowing it to be reused for further tests.
        let mut requests = self.requests.lock().unwrap_or_else(|err| err.into_inner());
        let completed: Vec<Result<T, ()>> = requests
            .extract_if(|_, req| !matches!(req.status, RequestStatus::InProgress))
            .map(|(_, mut req)| req.data.take().ok_or(()))
            .collect();
        drop(requests);

        for data in completed.into_iter().flatten() {
            cb(data);
        }
    }
}

struct InternalCallback<T> {
    queue: Arc<InternalQueue<T>>,
}

// impl<T: Send + Sync + 'static<T> for InternalCallback<T> {
//     fn call(&self, _doc_id: usize, result: Result<T, Option<String>>) {
//         match result {
//             Ok(data) => self.queue.record_success(Some(data), self.request_id),
//             Err(err) => {
//                 if let Some(msg) = err {
//                     eprintln!("{msg}");
//                 }
//                 self.queue.record_failure(self.request_id);
//             }
//         }
//     }
// }
